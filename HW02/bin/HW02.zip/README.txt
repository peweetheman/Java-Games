Patrick Phillips pphill10
Class ID 107
Lab 2

There is one class file for all sections of the lab.
This lab overall, explored various ways of implementing methods to handle an array with an unknown type.
Generics were primarily used to do so, but other sections used overloading or a functional interface to solve the same issue.
The functional interface problem #6 was implemented by creating a Function object that found the max char in a given array of Character objects.
