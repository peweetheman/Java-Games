Patrick Phillips
Class ID 108
UR Calculator Project

Only one class was made. Compile and run.

Project includes all standard features. Several maps are used for convenience. The program 
prompts the user then takes infix and adds spaces so it is easy to turn into an array. Then
it switches it to a postfix expression and finally evaluates it. Errors are checked for throughout, 
but most were tried to be dealt with in a "check" method.

Extra Credit: Also includes modulus and exponent math functions as well, and can take variable name
to be any string of characters except with spaces because instructor specifically said not to accept 
spaces in variable names.