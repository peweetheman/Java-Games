Patrick Phillips
pphill10
LAB PARTNER: BRANDON TOOPS

Compile and run test classes. 