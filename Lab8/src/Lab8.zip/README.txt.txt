Patrick Phillips
Class ID : 103
Lab Partner: Brandon Toops

Four files submitted, one for each problem. 