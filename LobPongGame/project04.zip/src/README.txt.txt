Patrick Phillips and Brandon Toops
pphill10, btoops
Lob Pong Game Project 04
Lab Section Tuesday-Thursday 9:40-10:55 Gavet 208

First project option. Compile and run with eclipse. Extract all files and run "Game" class.
Bombs and powerups added for first extra credit option, highscore table added for a second. 

Controls:
left and right arrow keys

Score:
score 1 for each bounce and 10 for each beaten level

Strategy:
get lucky and move your paddle to catch the ball
beat all six levels and win a prize!