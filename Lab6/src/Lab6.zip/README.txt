Patrick Phillips
Class ID: 107
No Partner

The lab included solving two problems, with optional recursion. I chose to use recursion for both. 
The first problem was to find how many ways one could make change using 25, 10, 5, and 1 as 
the denomonations, given an integer number of cents. To solve the problem, I made the method
call a helper function which kept track of the index in an array that had the denomonatations stored.
The second problem was to find a way that the chess board could have eight queens, none of which
attacked eachother. This problem I used a helper function to check if a move was valid, as in 
no other queens had been placed on the board that were attacking it. Then I used recursion to help 
loop through colums which I now realize has an 'n' at the end of it. 