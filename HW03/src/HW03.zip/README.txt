Patrick Phillips pphill10
Class ID 107
Lab 3

There were three tasks in this lab. In the first task, two functions were made.
The first function printed a 2D array, and the second function printed a 2D array list, or an array list containing array lists.
In the second task four functions were made to produce running sums of 2D arrays. Double for loops
were used for each of the methods to sum the element and the "runningSum" variable.
In the last task, prenamed methods were written to print integers in an arraylist iterating 
in different ways. Each task is in a seperate Java file named according to instructions.
