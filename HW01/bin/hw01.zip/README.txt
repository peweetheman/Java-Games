Patrick Phillips
pphill10
Assignment 1

Problems 01 and 02 are together in same class